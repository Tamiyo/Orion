---
layout: default
title: Design Docs
nav_order: 8000
has_children: true
---

<!--
© 2016 and later: Unicode, Inc. and others.
License & terms of use: http://www.unicode.org/copyright.html
-->

# Design Docs

